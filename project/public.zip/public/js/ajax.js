$(function(){
    $.ajax({
        url:"http://127.0.0.1/city",
        type:"get",
        dataType:"json",
            success:function(val){
            var box=""
                for(var i=0;i<val.length;i++){
                var v=val[i]
                    box+=`<option value="${v.cid}" >${v.cname}</option>`
                }
                document.getElementById("yycity").innerHTML=box

            }
    })
})

$("#yycity").change(function(e){
    var cid=$(this).val()
    $.ajax({
        url:"http://127.0.0.1/area",
        data:{cid},
        type:"get",
        dataType:"json",
        success:function(val){
            console.log(val)
            var box=""
            var jbox=""
            for(var i=0;i<val.length;i++){
                var v=val[i]

                box+=`<option value="${v.aid}" >${v.aname}</option>`
                jbox+=`<option>${v.aname}方面经销商</option>`
            }
            document.getElementById("yyarea").innerHTML=box
            document.getElementById("jxs").innerHTML=jbox
        }
    })
})

