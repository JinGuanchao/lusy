$(function (){
    //头

    $.ajax({
        url:"head.html",
        // type:"get",
        success:function(ppp){
            $(ppp).replaceAll("#hhh")
        }
    })
    //面包屑
    $.ajax({
        url:"head-footer.html",
        type:"get",
        success:function(ppp){
            $(ppp).replaceAll("#hf")
        }
    })
    //底部
    $.ajax({
        url:"bottom.html",
        type:"get",
        success:function(ppp){
            $(ppp).replaceAll("#bbb")
        }
    })
})