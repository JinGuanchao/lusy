$("#toptabbar").mouseenter(function(e){
    $(e.target).siblings().removeClass("hover")
    $(e.target).addClass("hover")


    num=$(e.target).attr("num")
    var k
    switch(num){
        case "1": k="Y1.html";n=1;break;
        case "2": k="Y2.html";n=2;break;
        case "3": k="Y3.html";n=3;break;
        case "4": k="Y4.html";n=4;break;
        case "5": k="Y5.html";n=5;
    }
    sessionStorage.setItem("jjj",k)
    sessionStorage.setItem("nnn",n)
    $.ajax({

        url:k,
        type:"get",
            success:(function(ppp){
                $("#jxsyr").html(ppp)
                console.log(k)
            })
    })               //$(ppp).replaceAll("#jxsyr").attr("id","jxsyr")



})

 $(window).load(function(){
     if(sessionStorage.getItem("jjj"))
     {k=sessionStorage.getItem("jjj")
        n=sessionStorage.getItem("nnn")}
     else
         {k="Y1.html";n="1"}

   $("#toptabbar>li").each(function(){
       if($(this).attr("num")==n){
           $(this).attr("class","hover")
       }
   })




   $.ajax({
        url:k,
         type:"get",
         success:(function(ppp){
         $("#jxsyr").html(ppp)})
     })
})

 $("#formbtn").click(function(){alert("提交成功")})





