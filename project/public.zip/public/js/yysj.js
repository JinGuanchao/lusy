(function() {
    //定义一个变量
    var b=1
    var a=0
    var cx
    var name
    var tel
    var city
    var sex


//验证是否手动选了默认
    $("#ztcx").change(function () {
        if ($(this).val() == "v00") {
            $("#err").html("请勿选择车型默认项").attr({class: "error"})
            if(a>0){b=0}else{a=0}

        }
        else {
            $("#err").html("为了给您带来更全面的服务，请填写").attr({class: "success"})
            if(a>0){b=1}else{a=1}
            cx=$(this).val()
        }
    })

//验证名字长度
    $("#yysjname").blur(function () {
        //判断上方是否通过
       if(a>=1) {

           var reg = /^([\u4E00-\u9FA5]{2,8})$/
           var val = $(this).val()
           if (reg.test(val) == false) {
               $("#err").html("请输入2-8位中文").attr({class: "error"})

               if(a>1){ b=0 }else{a=1}

           }
           else {
               $("#err").html("为了给您带来更全面的服务，请填写").attr({class: "success"})
               if(a>1){b=1}else{a=2}
               name=val
           }
       }
       else{$("#err").html("前项有误或未填写/选择，请检查").attr({class: "error"})}
    })
//验证手机号
    $("#tel").blur(function () {
        //判断上方是否通过
        if(a>=2) {

            var reg = /^([1][3-9][0-9]{9})$/
            var val = $(this).val()
            if (reg.test(val) == false) {
                $("#err").html("手机号格式错误").attr({class: "error"})

                if(a>2){b=0}else{a=2}
            }
            else {
                $("#err").html("为了给您带来更全面的服务，请填写").attr({class: "success"})

                if(a>2){b=1}else{a=3;$("#yycity").attr("disabled",false)}
                console.log(a)
                tel=val

            }
        }
        else{$("#err").html("前项有误或未填写/选择，请检查").attr({class: "error"})
            $(this).val("")}
    })
//验证地区是否手动默认

        $("#yycity").change(function () {
            if (a >= 3) {
                if ($(this).val() == 1) {
                    $("#err").html("请勿选择所在地的默认项").attr({class: "error"})
                    if (a > 3) {
                        b = 0
                    } else {
                        a = 3
                    }
                }
                else {
                    $("#err").html("为了给您带来更全面的服务，请填写").attr({class: "success"})
                    if (a > 3) {
                        b = 1
                    } else {
                        a = 4
                    }
                    city = $(this).val()
                }
            }
            else {
                $("#err").html("前项有误或未填写/选择，请检查").attr({class: "error"})

            }
        })



    //点击提交时动作
  $("#subfrom").click(function(){

        if(a==4&&b==1) {
            sex=$("input[name=sex]:checked").val()
            //传值
                $.ajax({
                    url:"http://127.0.0.1/maa",
                    data:{cx,name,tel,city,sex},
                    type:"get",
                    success:function(ma){
                        console.log(ma)
                    }
                })
            document.getElementById("form-list").innerHTML = `<h1>预约已提交</h1>`

        }
        else{ $("#err").html("前项有误或未填写/选择，请检查").attr({class: "error"})}
    })



})()